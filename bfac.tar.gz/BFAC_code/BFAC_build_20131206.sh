perl BFAC_build_20131206.pl -r ref_Bdello.txt -dbpr ./Bdellovibrio_bacteriovorus_HD100_uid61595/
perl BFAC_build_20131206.pl -r ref_Ecoli.txt -dbpr ./Escherichia_coli_K_12_substr__DH10B_uid58979/
perl BFAC_build_20131206.pl -r ref_Ecoli2.txt -dbpr ./Escherichia_coli_K_12_substr__MDS42_uid193705/
