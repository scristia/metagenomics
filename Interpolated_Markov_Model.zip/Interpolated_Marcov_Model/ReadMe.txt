All programs are in src/
All libraries are in lib/
All java docs are in doc/
All data are in data/
All outputs are in output/
dna_process.py is used to convert the original file into my required format
There are five inputs: ./data/DNA.train ./data 400 6 50
First two are data sets and the third is threshold; fourth is order; fifth is score standard