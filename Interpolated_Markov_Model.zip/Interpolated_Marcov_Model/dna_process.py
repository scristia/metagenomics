#################
###DNA Process###
#################

###Zhou Ye###
###12/06/2013###

###File To Be Processed###
refB = "NC_005363_Bdello.fna"
refE = "NC_010473_Ecoli.fna"
testB = "NC_005363_Bdello-454.9d38eefd.fna"
testE = "NC_010473_Ecoli-454.9d3a5a57.fna"

def passRef(filename):
	ref = open(filename, "r")
	data = ref.readlines()
	dna = ""
	for i in range(1, len(data)):
		dna += data[i].strip()
	ref.close()
	return(dna)

def passTest(filename):
	test = open(filename, "r")
	data = test.readlines()
	dna = []
	count = 0
	for i in range(0, len(data)):
		line = data[i].strip()
		if line.startswith(">"):
			dna.append("")
			count += 1
		else:
			dna[count-1] += line
	test.close()
	return(dna)

###Create Referece Set###
dnaRefB = passRef(refB)
outputB = dnaRefB+"\t"+"B"+"\n"
dnaRefE = passRef(refE)
outputE = dnaRefE+"\t"+"E"+"\n"
refSet = open("DNA.train", "w")
refSet.write(outputB)
refSet.write(outputE)
refSet.close()

###Create Test Set###
dnaTestB = passTest(testB)
outputTB = ""
for s in dnaTestB:
	outputTB += s+"\t"+"B"+"\n"
dnaTestE = passTest(testE)
outputTE = ""
for s in dnaTestE:
	outputTE += s+"\t"+"B"+"\n"
testSet = open("DNA.test", "w")
testSet.write(outputTB)
testSet.write(outputTE)
testSet.close()
