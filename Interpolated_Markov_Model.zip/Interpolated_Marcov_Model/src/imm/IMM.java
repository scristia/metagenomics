package imm;

/**
 * Interpolated Markov Model
 * @author Zhou Ye
 */

import java.io.*;
import java.util.*;

import org.apache.commons.math3.distribution.ChiSquaredDistribution;

public class IMM {
	
	private List<DNA> reference = new ArrayList<DNA>(); //all DNA sequences for reference
	private List<DNA> test = new ArrayList<DNA>(); //all DNA sequences for test
	private int threshold = 400;
	private int order = 8;
	private int standard = 30;
	private char[] base = {'A', 'C', 'G', 'T'}; //all bases for DNA
	private Map<DNA, List<Map<String, Info>>> result = new HashMap<DNA, List<Map<String, Info>>>(); //all probability and lambda for each order
	
	/**
	 * Constructor
	 * @param threshold Decide how large number of data is sufficient
	 * @param order Order of Markov model
	 * @param standard The bottom line of score we will do classification
	 */
	public IMM(int threshold, int order, int standard) {
		this.threshold = threshold;
		this.order = order;
		this.standard = standard;
	}
	
	/**
	 * The information of DNA string
	 * @author zhou Ye
	 */
	private class DNA {
		
		public final String seq;
		public final String label;
		
		public DNA(String seq, String label) {
			this.seq = seq;
			this.label = label;
		}
		
		@Override
		public String toString() {
			String result = seq+":"+label;
			return result;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (obj == null)
	            return false;
	        if (obj == this)
	            return true;
	        if (!(obj instanceof DNA))
	            return false;
	        DNA rhs = (DNA) obj;
	        if (rhs.label.equals(this.label) && rhs.seq.equals(this.seq)) {
	        	return true;
	        }
	        else {
	        	return false;
	        }
		}
		
		@Override
		public int hashCode() {
			int result = 31;
			result = result+37*seq.hashCode();
			result = result+37*label.hashCode();
			return result;
		}
	}
	
	/**
	 * Parameters for IMM
	 * @author Zhou Ye
	 */
	private class Info {
		
		public double[] prob = {0, 0, 0, 0};
		public double lambda = 1;
		
		@Override
		public String toString() {
			return Arrays.toString(prob)+" "+lambda;
		}
	}
	
	/**
	 * Pass the reference genome
	 * @param name Reference genome file name
	 */
	private void processRef(String name) {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(new File(name)));
			String line = null;
			while ((line = br.readLine())!=null) {
				String[] temp = line.trim().split("\t");
				reference.add(new DNA(temp[0], temp[1]));
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) { 
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Pass the test genome
	 * @param name Test genome file name
	 */
	private void processTest(String name) {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(new File(name)));
			String line = null;
			while ((line = br.readLine())!=null) {
				String[] temp = line.trim().split("\t");
				test.add(new DNA(temp[0], temp[1]));
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) { 
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Calculate the IMM parameters
	 * @param dna Reference DNA string
	 * @return The list of parameters for different order
	 */
	private List<Map<String, Info>> computeConditionalParameter(DNA dna) {
		List<Map<String, Info>> allProb = new ArrayList<Map<String, Info>>();
		for (int i=0; i<=order; i++) {
			Map<String, Info> prob = new HashMap<String, Info>();
			for (int j=i; j<dna.seq.length(); j++) {
				/*
				 * compute counts
				 */
				if (i==0) {
					if (!prob.containsKey("zero")) {
						prob.put("zero", new Info());
					}
					char b = dna.seq.charAt(j);
					int index = Arrays.binarySearch(base, b);
					if (index<0) {
						continue;
					}
					Info temp = prob.get("zero");
					temp.prob[index]++;
					prob.put("zero", temp);
				}
				else {
					String str = dna.seq.substring(j-i, j);
					if (!prob.containsKey(str)) {
						prob.put(str, new Info());
					}
					
					char b = dna.seq.charAt(j);
					int index = Arrays.binarySearch(base, b);
					if (index<0) {
						continue;
					}
					Info temp = prob.get(str);
					temp.prob[index]++;
					prob.put(str, temp);
				}
			}
			if (i==0) {
				allProb.add(prob);
			}		
			else {
				/*
				 * compute lambda
				 */
				for (String seq : prob.keySet()) {
					Info count = prob.get(seq);
					double sum = count.prob[0]+count.prob[1]+count.prob[2]+count.prob[3];
					double lambda = 0;
					if (sum>threshold) {
						lambda = 1;
					}
					else {
						String comp = seq.substring(1);
						Info countComp = null;
						if (allProb.get(i-1).containsKey(comp)) {
							countComp = allProb.get(i-1).get(comp);
						}
						else {
							countComp = new Info();
						}
						ChiSquaredDistribution xi = new ChiSquaredDistribution(3); //(2-1)*(4-1)
						double x = computeChiSquare(count, countComp);
						double pValue = 1-xi.cumulativeProbability(x);
						if (pValue <= 0.05) {
							lambda = 0;
						}
						else {
							lambda = sum/threshold*pValue;
						}
					}
					count.lambda = lambda;
					prob.put(seq, count);
				}
				/*
				 * change the past counts into probability
				 */
				Map<String, Info> lastProb = allProb.get(i-1);
				for (String seq : lastProb.keySet()) {
					Info pastInfo = lastProb.get(seq);
					double[] temp = normalize(pastInfo.prob);
					pastInfo.prob = temp;
					lastProb.put(seq, pastInfo);
				}
				allProb.set(i-1, lastProb);
				/*
				 * change the current counts into probability since it is the largest order
				 */
				if (i==order) {
					for (String seq : prob.keySet()) {
						Info currentInfo = prob.get(seq);
						double[] temp = normalize(currentInfo.prob);
						currentInfo.prob = temp;
						prob.put(seq, currentInfo);
					}
				}
				allProb.add(prob);
			}
		}
		return allProb;
	}
	
	/**
	 * Compute the Chi-square test statistics
	 * @param count1 The set of counts
	 * @param count2 The set of counts
	 * @return
	 */
	private double computeChiSquare(Info count1, Info count2) {
		double rowSumA = count1.prob[0]+count2.prob[0];
		double rowSumT = count1.prob[1]+count2.prob[1];
		double rowSumC = count1.prob[2]+count2.prob[2];
		double rowSumG = count1.prob[3]+count2.prob[3];
		double colSum1 = count1.prob[0]+count1.prob[1]+count1.prob[2]+count1.prob[3];
		double colSum2 = count1.prob[0]+count1.prob[1]+count1.prob[2]+count1.prob[3];
		double total = colSum1+colSum2;
		if (total==0) {
			return 0;
		}
		double xi = 0;
		double eA1 = colSum1*rowSumA/total;
		if (eA1!=0) {
			xi += Math.pow((count1.prob[0]-eA1), 2)/eA1;
		}
		double eT1 = colSum1*rowSumT/total;
		if (eT1!=0) {
			xi += Math.pow((count1.prob[1]-eT1), 2)/eT1;
		}
		double eC1 = colSum1*rowSumC/total;
		if (eC1!=0) {
			xi += Math.pow((count1.prob[2]-eC1), 2)/eC1;
		}
		double eG1 = colSum1*rowSumG/total;
		if (eG1!=0) {
			xi += Math.pow((count1.prob[3]-eG1), 2)/eG1;
		}
		double eA2 = colSum2*rowSumA/total;
		if (eA2!=0) {
			xi += Math.pow((count2.prob[0]-eA2), 2)/eA2;
		}
		double eT2 = colSum2*rowSumT/total;
		if (eT2!=0) {
			xi += Math.pow((count2.prob[1]-eT2), 2)/eT2;
		}
		double eC2 = colSum2*rowSumC/total;
		if (eC2!=0) {
			xi += Math.pow((count2.prob[2]-eC2), 2)/eC2;
		}
		double eG2 = colSum2*rowSumG/total;
		if (eG2!=0) {
			xi += Math.pow((count2.prob[0]-eG2), 2)/eG2;
		}
		return xi;
	}
	
	/**
	 * Normalize counts to probability
	 * @param count The array of counts
	 * @return Probability
	 */
	private double[] normalize(double[] count) {
		double sum = count[0]+count[1]+count[2]+count[3];
		if (sum==0) {
			return count;
		}
		else {
			count[0] = count[0]/sum;
			count[1] = count[1]/sum;
			count[2] = count[2]/sum;
			count[3] = count[3]/sum;
			return count;
		}
	}
	
	/**
	 * Compute IMM score
	 * @param dna Reference DNA string
	 * @param p Position
	 * @param n Order
	 * @return IMM score
	 */
	private double computeIMM(DNA dna, int p, int n) {
		int index = Arrays.binarySearch(base, dna.seq.charAt(p));
		if (index<0) {
			return 0;
		}
		if (n==0) {
			return result.get(dna).get(0).get("zero").prob[index];
		}
		else {
			if (result.get(dna).get(n).containsKey(dna.seq.subSequence(p-n, p))) {
				double lambda = result.get(dna).get(n).get(dna.seq.substring(p-n, p)).lambda;
				double prob = result.get(dna).get(n).get(dna.seq.substring(p-n, p)).prob[index];
				return lambda*prob+(1-lambda)*computeIMM(dna, p, n-1);
			}
			else {
				return computeIMM(dna, p, n-1);
			}
		}
	}
	
	/**
	 * Calculate the required statistics
	 * @param pre Predictor
	 * @param fac True label
	 * @return
	 */
	private double[] computeStat(String[] pre, String[] fac) {
		assert pre.length==fac.length;
		double[] stat = {0, 0, 0, 0, 0}; //accuracy, sensitivity_B, specificity_B, sensitivity_E, specificity_E
		double countBB = 0;
		double countEB = 0;
		double countNB = 0;
		double countBE = 0;
		double countEE = 0;
		double countNE = 0;
		for (int i=0; i<pre.length; i++) {
			if (pre[i].equals("B") && fac[i].equals("B")) {
				countBB++;
			}
			if (pre[i].equals("E") && fac[i].equals("B")) {
				countEB++;
			}
			if (pre[i].equals("N") && fac[i].equals("B")) {
				countNB++;
			}
			if (pre[i].equals("B") && fac[i].equals("E")) {
				countBE++;
			}
			if (pre[i].equals("E") && fac[i].equals("E")) {
				countEE++;
			}
			if (pre[i].equals("N") && fac[i].equals("E")) {
				countNE++;
			}
		}
		System.out.println(countBB+" "+countEB+" "+countNB+" "+countBE+" "+countEE+" "+countNE);
		stat[0] = (countEE+countBB)/(countBB+countEB+countNB+countBE+countEE+countNE);
		stat[1] = countBB/(countBB+countEB+countNB);
		stat[2] = (countNE+countEE)/(countBE+countEE+countNE);
		stat[3] = countEE/(countBE+countEE+countNE);
		stat[4] = (countBB+countNB)/(countBB+countEB+countNB);
		return stat;
	}

	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();	
		String reference = args[0]; //reference 
		String test = args[1]; //test
		int threshold = Integer.parseInt(args[2]);
		int order = Integer.parseInt(args[3]);
		int standard = Integer.parseInt(args[4]);
		IMM imm = new IMM(threshold, order, standard);
		imm.processRef(reference);
		System.out.println("Finish Processing Reference");
		for (DNA dna : imm.reference) {
			imm.result.put(dna, imm.computeConditionalParameter(dna));
		}
		System.out.println("Finish Learning Parameters");
		imm.processTest(test);
		System.out.println("Finish Processing Testing");
		String[] predictor = new String[imm.test.size()];
		String[] fact = new String[imm.test.size()];
		for (int i=0; i<imm.test.size(); i++) {
			DNA dna = imm.test.get(i);
			double score = -1;
			DNA best = null;
			for (DNA refer : imm.reference) {
				double temp = 0;
				for (int p=0; p<dna.seq.length(); p++) {
					if (p>=imm.order) {
						temp += imm.computeIMM(refer, p, imm.order);
					}
					else {
						temp += imm.computeIMM(refer, p, p);
					}
				}
				if (temp>score) {
					score = temp;
					best = refer;
				}
			}
			if (score < imm.standard) {
				predictor[i] = "N";
			}
			else {
				if (!best.label.equals("B") && !best.label.equals("E")) {
					predictor[i] = "N";
				}
				else {
					predictor[i] = best.label;
				}
			}
			fact[i] = dna.label;
		}
		System.out.println("Finish Computing IMM Score");
		double[] stat = imm.computeStat(predictor, fact);
		System.out.println("Accuracy: "+stat[0]);
		System.out.println("Sensitivity(B): "+stat[1]);
		System.out.println("Specificity(B): "+stat[2]);
		System.out.println("Sensitivity(E): "+stat[3]);
		System.out.println("Specificity(E): "+stat[4]);
		long endTime = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		System.out.println(totalTime/1000);
	}
	
}
