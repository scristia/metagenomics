#######################################################################
##### Description:This function below is to calculate the accuracy  ###
#####             and specificity for Bowtie method.                ###                               ###
##### How to run: Pleas set the value of 'projectpath' variable to  ###
#####             the directory where you extract XX.zip.           ###
##### Result :    You can find the statistics in 'stats.txt' file   ###                                   ###
#######################################################################          
import os
import re
def getScore(fast_url):
    scores = {}
    classlabel = {}

    # This is to compute the number of labels after classification to calculate senstivity.
    num_lb = 0
    num_le = 0
    num_lo = 0
    # Run the bowtie
    indexB = projectpath + '/data/index/Bdellovibrio/bacteriovorus/bacteriovorus'
    indexE = projectpath + '/data/index/Escherichia/coli/coli'
    indexO = projectpath + '/data/index/Escherichia/other/other'
    os.chdir(projectpath + '/bowtie2-2.1.0')    
    fastapath = fast_url
    cmd1 = './bowtie2-align -f -x ' + indexB + ' -U ' + fastapath + ' -S '+ projectpath+ '/stdoutB'
    os.system(cmd1)
    cmd2 = './bowtie2-align -f -x ' + indexE + ' -U ' + fastapath + ' -S '+ projectpath+ '/stdoutE'
    os.system(cmd2)
    cmd3 = './bowtie2-align -f -x ' + indexO + ' -U ' + fastapath + ' -S '+ projectpath+ '/stdoutO'
    os.system(cmd3)

    # Get the scores generated from Bowtie
    os.chdir(projectpath)
    f = open('stdoutB')
    lines = f.readlines()
    for each in lines:
        if re.match('r',each):
            tmpline = each.split('\t')
            name =tmpline[0].split('|')[0]
            scores[name] = []
            scores[name].append(tmpline[4])      
    f = open('stdoutE')
    lines = f.readlines()
    for each in lines:
        if re.match('r',each):
            tmpline = each.split('\t')
            name =tmpline[0].split('|')[0]
            scores[name].append(tmpline[4])   
    f = open('stdoutO')
    lines = f.readlines()
    for each in lines:
        if re.match('r',each):
            tmpline = each.split('\t')
            name =tmpline[0].split('|')[0]
            scores[name].append(tmpline[4])        
    # Set the labels to the reference when it has max alignment score
    for key in scores.keys():
        value = max(scores[key])
        label = scores[key].index(value)
        classlabel[key] = label
        if label == 0:
            num_lb = num_lb+1
        elif label == 1:
            num_le = num_le+1
        else:
            num_lo = num_lo+1
    return (num_lb,num_le,num_lo)

if __name__ == "__main__":
    projectpath = '/home/ccya/workplace/439/project'
    fast_url_e = projectpath+'/data/fasta/ecoli.fna'
    label_e = getScore(fast_url_e)
    fast_url_b = projectpath+'/data/fasta/bdello.fna'
    label_b = getScore(fast_url_b)
    acc = float(label_b[0]+label_e[1])/10000.00
    sen_e = float(label_e[1])/5000.00
    spe_e = float(label_b[0]+label_b[2])/5000.00
    sen_b = float(label_b[0])/5000.00
    spe_b = float(label_e[1]+label_e[2])/5000.00
    f = open("stats.txt", "w")
    print label_b
    print label_e
    print >>f, "Accuracy is %f" %acc
    print >>f, "Senstivity for Ecoli is %f" %sen_e
    print >>f, "Senstivity for Bdellovibrio is %f" %sen_b
    print >>f, "Specificity for Ecoli is %f" %spe_e
    print >>f, "Specificity for Bdellovibrio is %f" %spe_b
    