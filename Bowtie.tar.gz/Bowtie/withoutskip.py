import os
import re
import time

################ Build the tree structure based on the reference substree 
class Node(object):
    def __init__(self, data, parent): #data is the directory
        self.data = data
        self.parent = parent #parent is a node!
        self.children = []

    def add_child(self, obj):
        self.children.append(obj)
        
def getDirList(curnode):
    url = curnode.data
    files = os.listdir(url)   
    for file in files:   
        myfile = url + "/" + file   
        size = os.path.getsize(myfile)   
        if os.path.isfile(myfile):
            child = Node(myfile,curnode)   
            curnode.add_child(child)

        if os.path.isdir(myfile):    
            child = Node(myfile,curnode)
            curnode.add_child(child)
            getDirList(child)  

def buildTree(url):
    root = Node(url,None)
    getDirList(root)
    return root

def getFirstLeaf(node):
    child = node.children[0]
    if child.data.endswith('.bt2'):
        return node
    else:
        curnode = node.children[0]
        return getFirstLeaf(curnode)

def isLeaf(node):
    child = node.children[0]
    if child.data.endswith('.bt2'):
        return True
    else:
        return False
    
def hasNextBranch(node):
    parent = node.parent
    grandpa = parent.parent
    numchild = len(grandpa.children)       
    index = grandpa.children.index(parent)
    if index+1 < numchild:  
        return True
    else:
        return False

def getNextBranch(node):
    grandpa = node.parent.parent
    parent = node.parent
    index = grandpa.children.index(parent)
    if isLeaf(grandpa.children[index+1]):
        next_node = grandpa.children[index+1]
        return next_node
    else:
        tmp = grandpa.children[index+1]
        next_node = getFirstLeaf(tmp)
        return next_node 

def hasNeighbor(node):
    parent = node.parent
    numchild = len(parent.children)       
    index = parent.children.index(node)
    if index+1 < numchild:
        return True
    else:
        return False   

def getNeighbor(node):
    parent = node.parent
    numchild = len(parent.children)       
    index = parent.children.index(node)
    return parent.children[index+1]


#######################################################################
##### General description: this function below is almost the same #####
##### as previous function. In this function, instead of choosing #####
##### next reference based on the scores got before, it simply    #####
##### traverse all the reference we have to find the best socre   #####
#######################################################################

def getAligned(node,fast_url):

    ############  Align  #############
    os.chdir(projectpath + '/bowtie2-2.1.0')
    indexpath = node.data
    print "index :%s" %indexpath
    fastapath = fast_url
    basename = node.data.split('/')[-1]
    cmd = './bowtie2-align -f -x ' + indexpath +'/'+ basename + ' -U ' + fastapath + ' -S ' +projectpath + '/stdout'
    os.system(cmd)
    
    ############  Get scores  #############
    os.chdir(projectpath)
    f = open("stdout")
    lines = f.readlines()
    scores = []
    for each in lines:
        if re.match('r',each):
            tmpline = each.split('\t')
            scores.append(tmpline[4])
    threshold = 10
    previous_scores = alignscores[fast_url]
    sum = 0
    for each in scores:
        sum = sum + int(each)
    averagescore = 0 if sum == 0 else sum/len(scores)  
    if averagescore > previous_scores:
        alignscores[fast_url] = averagescore
    if hasNeighbor(node):
        next_node = getNeighbor(node)
        return getAligned(next_node,fast_url)
    else:
        if hasNextBranch(node):
            next_node = getNextBranch(node)
            return getAligned(next_node, fast_url)
        else:
            return alignscores[fast_url]

start = time.time()
alignscores = {}
projectpath = '/home/ccya/workplace/439/project'
url = projectpath + '/data/index'
fast_url = projectpath+'/data/fasta/ecoli.fna'
root = buildTree(url)
curnode = getFirstLeaf(root)
alignscores[fast_url] = 0
# getScore(fast_url)
score = getAligned(curnode,fast_url)
print 'the final score is %s' %score
duration = (time.time()-start)
print 'Time spent is %f' %duration