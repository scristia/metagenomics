1 Please download the index data 'index.tar.gz' from the ugrad cluster.It's on /home/schu14/cs439 and put it into the data folder inside the folder you extract from 'Bowtie.tar.gz'
2 'bowtie_with_skip.py' : This is the implementation for the improvment mentioned in report;
3 'withoskip.py': This is a navie method which align the test data to every reference data we have;
4 'statistics.py': This is to calculate some statistics like accuracy and sensitivity for Bowtie. You will find the summary in stats.txt file
5 In oreder to run, please change all the value of 'projectpath' to the path for this folder.
6 Inside the data file, fasta folder contains test data and index folder have all the index for the reference set I use.
7 This part is implemented by Shuya Chu.Contact me if you have any problem when running it. Email: shuya.chu@jhu.edu
